# CRUD Mongo

Para rodar digite?

yarn install

yarn start

ou

npm install

npm start
